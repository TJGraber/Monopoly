package com.example.tj_monopoly;

import javafx.animation.KeyFrame;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;

public class MonopolyController implements Initializable {

    //region FXML Compontents
    @FXML
    Button firstDie_btn, secondDie_btn;
    @FXML
    ImageView firstDie_img, secondDie_img, playerPiece1, propertyPreview_img;
    @FXML
    AnchorPane space0, space1, space2, space3, space4, space5, space6, space7, space8, space9, space10, space11,
            space12, space13, space14, space15, space16, space17, space18, space19, space20, space21, space22, space23,
            space24, space25, space26, space27, space28, space29, space30, space31, space32, space33, space34, space35,
            space36, space37, space38, space39;
    @FXML
    AnchorPane outerBoard_ap, innerBoard_ap;
    @FXML
    Label propertyPreviewPrice_lbl, propertyPreviewName_lbl;
    //endregion

    Player player;

    Image[] diceImages = {
            new Image("dOne.png"),
            new Image("dTwo.png"),
            new Image("dThree.png"),
            new Image("dFour.png"),
            new Image("dFive.png"),
            new Image("dSixFixed.png")
    };

    AnchorPane[] spaces;
    Tile[] tiles = new Tile[40];

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
    int randomIndexD1;
    int randomIndexD2;
    public void rollDice(){
        //Dice will flicker every 0.1 seconds
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(0.1), event ->{

            Random random = new Random();
            randomIndexD1 = random.nextInt(6);
            randomIndexD2 = random.nextInt(6);

            firstDie_img.setImage(diceImages[randomIndexD1]);
            secondDie_img.setImage(diceImages[randomIndexD2]);
        }));

        //15 Total "bounces"
        timeline.setCycleCount(15);
        timeline.play();

        timeline.setOnFinished(event -> {
            moveToSpace(randomIndexD1 + 1 + randomIndexD2 + 1);
            //System.out.println("hello");
        });
    }

    public void setUpPlayers(){
        player = new Player(0, playerPiece1);
    }
    public void setUpSpaces(){
        spaces = new AnchorPane[]{space0, space1, space2, space3, space4, space5, space6, space7, space8, space9, space10, space11,
                space12, space13, space14, space15, space16, space17, space18, space19, space20, space21, space22, space23,
                space24, space25, space26, space27, space28, space29, space30, space31, space32, space33, space34, space35,
                space36, space37, space38, space39};

        setUpTiles();

    }
    public void setUpTiles(){

        for(int i = 0; i < spaces.length; i++){

            boolean isCorner = false;

            if(i % 10 == 0){
                isCorner = true;
            }



            tiles[i] = new Tile(spaces[i], isCorner);
        }

    }

    public void moveToSpace(int numberOfSpaces){

        int tileBeforeMove = player.getCurrentTileIndex();

        //Checking to see if new tile will be going back to start of list (going to or past go)
        if(tileBeforeMove + numberOfSpaces < spaces.length){

            player.setCurrentTile(tileBeforeMove + numberOfSpaces);
        }else{

            int overflow = tileBeforeMove + numberOfSpaces;
            player.setCurrentTile(overflow - spaces.length);
        }

        int newTileIndex = player.getCurrentTileIndex();


        int addedRotation = 0;
        int boardSideBeforeMoving = tileBeforeMove / 10;
        int boardSideAfterMoving = newTileIndex / 10;

        //If Player goes from side 0 (bottom) to side 2 (top) then number of sides jumped = 2

        int numberOfSidesJumpedTo = Math.abs(boardSideAfterMoving - boardSideBeforeMoving);

        //If you are jumping from side 3 to side 0, the player has rounded go
        if(boardSideBeforeMoving > boardSideAfterMoving){


            if(numberOfSidesJumpedTo == 3){
                numberOfSidesJumpedTo = 1;

                //If numberOfSidesJumpedTo == 2, value is already correct

            }else if(numberOfSidesJumpedTo == 1){
                numberOfSidesJumpedTo = 3;
            }
        }

        addedRotation = numberOfSidesJumpedTo * -90;


        if(numberOfSidesJumpedTo > 0){
            RotateTransition outerRotation = new RotateTransition(Duration.millis(2000 * numberOfSidesJumpedTo), outerBoard_ap);
            //Board will rotate by -90 degrees for each side jumped to, using cycle count so that animation will
            //play at the same speed no matter the number of jumps
            outerRotation.setByAngle(addedRotation);
            //rt.setCycleCount(numberOfSidesJumpedTo);
            outerRotation.play();

            RotateTransition innerRotation = new RotateTransition(Duration.millis(2000 * numberOfSidesJumpedTo), innerBoard_ap);
            innerRotation.setByAngle(-addedRotation);
            innerRotation.play();

            RotateTransition playerRotation = new RotateTransition(Duration.millis(2000 * numberOfSidesJumpedTo), playerPiece1);
            playerRotation.setByAngle(-addedRotation);
            playerRotation.play();
        }




        spaces[newTileIndex].getChildren().add(player.getPlayerIcon());

        //Set player icon to default X and Y
        player.getPlayerIcon().setLayoutX(25);
        player.getPlayerIcon().setLayoutY(25);

        if(!tiles[newTileIndex].isCornerTile()){

            //If new tile is not a corner tile, offset it necessary based on which side of the board
            //the new tile is on. By default, player location is set to corner offset
            if(boardSideAfterMoving == 0 || boardSideAfterMoving == 2){
                player.getPlayerIcon().setLayoutX(3);
            }else if(boardSideAfterMoving == 1 || boardSideAfterMoving == 3){
                player.getPlayerIcon().setLayoutY(3);
            }
        }



    }
}