package com.example.tj_monopoly;

import javafx.scene.image.ImageView;

public class Player {

    int currentTileIndex;

    ImageView playerIcon;

    public Player(int _currentTile, ImageView _playerIcon){

        currentTileIndex = _currentTile;
        playerIcon = _playerIcon;
    }

    public int getCurrentTileIndex(){
        return currentTileIndex;
    }

    public void setCurrentTile(int _currentTileIndex){
        currentTileIndex = _currentTileIndex;
    }

    public ImageView getPlayerIcon(){
        return playerIcon;
    }
}
