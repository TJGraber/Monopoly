package com.example.tj_monopoly;

import javafx.scene.layout.AnchorPane;

public class Tile {

    AnchorPane anchor;
    boolean isCornerTile;

    public Tile(AnchorPane anchor, boolean _isCornerTile){
        isCornerTile = _isCornerTile;
    }

    public AnchorPane getAnchor(){
        return anchor;
    }
    public boolean isCornerTile(){
        return isCornerTile;
    }
}