package com.example.tj_monopoly;

import javafx.animation.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Paint;
import javafx.util.Duration;

import java.io.File;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;

public class MonopolyController implements Initializable {

    //region FXML Compontents
    @FXML
    Button firstDie_btn, secondDie_btn, openCard_btn;
    @FXML
    ImageView firstDie_img, secondDie_img, playerPiece1, tilePreview_img;
    @FXML
    AnchorPane space0, space1, space2, space3, space4, space5, space6, space7, space8, space9, space10, space11,
            space12, space13, space14, space15, space16, space17, space18, space19, space20, space21, space22, space23,
            space24, space25, space26, space27, space28, space29, space30, space31, space32, space33, space34, space35,
            space36, space37, space38, space39;
    @FXML
    AnchorPane outerBoard_ap, innerBoard_ap, tilePreviewColor_ap, tilePreviewCard_ap;
    @FXML
    Label tilePreviewPrice_lbl, tilePreviewName_lbl;
    //endregion

    Player player;
    Audio audio = new Audio();

    ScaleTransition pulseCardTransition;

    Image[] diceImages = {
            new Image("dOne.png"),
            new Image("dTwo.png"),
            new Image("dThree.png"),
            new Image("dFour.png"),
            new Image("dFive.png"),
            new Image("dSixFixed.png")
    };

    AnchorPane[] spaces;
    Tile[] tiles = new Tile[40];

    String[] tileName = {
            "Go", "Battle Droid", "Community Chest", "General Grevious", "", "Millennium Falcon", "Captain Rex", "Chance",
            "Ahsoka Tano", "Arc Trooper Fives", "Jail", "Stormtrooper", "Death Star", "Director Krennic", "Grand Inquisitor",
            "Slave 1", "Wedge Antilles", "Community Chest", "Cassian Andor", "Han Solo", "Free Parking", "Count Dooku",
            "Chance", "Darth Maul", "Kylo Ren", "Star Destroyer", "Plo Koon", "Anakin Skywalker", "Starkiller Base",
            "Mace Windu", "Go To Jail", "Master Yoda", "Luke Skywalker", "Community Chest", "Obi-Wan Kenobi",
            "AT-AT Walker", "Chance", "Emperor Palpatine", "", "Darth Vader"
    };

    String[] tileImages = {
            "", "1_battleDroid.png", "", "2_grevious.png", "", "", "3_rex.png", "", "4_ahsoka.png", "5_fives.png",
            "6_stormtrooper.png", "", "7_krennic.png", "", "8_grandInquisitor.png", "", "9_wedge.png", "", "10_andor.png",
            "11_hanSolo.png", "", "12_countDooku.png", "", "13_darthMaul.png", "14_kyloRen.png", "", "15_ploKoon.png",
            "16_anakin.png", "", "17_maceWindu.png", "", "18_yoda.png", "19_luke.png", "", "20_obiWan.png", "", "",
            "21_palpatine.png", "", "22_darthVader.png"
    };

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        audio.setFile(4);
        audio.play();
        audio.loop();

        pulseDice();
    }
    int randomIndexD1;
    int randomIndexD2;

    public void rollDice(){

        audio.setFile(2);
        audio.play();

        //Dice will flicker every 0.1 seconds
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(0.1), event ->{

            Random random = new Random();
            randomIndexD1 = random.nextInt(6);
            randomIndexD2 = random.nextInt(6);

            firstDie_img.setImage(diceImages[randomIndexD1]);
            secondDie_img.setImage(diceImages[randomIndexD2]);
        }));

        //25 Total "bounces"
        timeline.setCycleCount(25);
        timeline.play();

        timeline.setOnFinished(event -> {
            handleBoardAfterDiceRoll(randomIndexD1 + 1 + randomIndexD2 + 1);
        });
    }
    public void pulseDice(){
        ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.4), firstDie_btn);
        scaleTransition.setByX(0.05f);
        scaleTransition.setByY(0.05f);
        scaleTransition.setCycleCount(Animation.INDEFINITE);
        scaleTransition.setAutoReverse(true);
        scaleTransition.play();

        ScaleTransition scaleTransition2 = new ScaleTransition(Duration.seconds(0.4), secondDie_btn);
        scaleTransition2.setByX(0.05f);
        scaleTransition2.setByY(0.05f);
        scaleTransition2.setCycleCount(Animation.INDEFINITE);
        scaleTransition2.setAutoReverse(true);
        scaleTransition2.play();
    }
    public void pulseCard(){
        pulseCardTransition = new ScaleTransition(Duration.seconds(0.5), tilePreviewCard_ap);
        pulseCardTransition.setByX(0.03f);
        pulseCardTransition.setByY(0.03f);
        pulseCardTransition.setCycleCount(Animation.INDEFINITE);
        pulseCardTransition.setAutoReverse(true);
        pulseCardTransition.play();
    }

    public void setUpPlayers(){
        player = new Player(0, playerPiece1);
    }
    public void setUpSpaces(){
        spaces = new AnchorPane[]{space0, space1, space2, space3, space4, space5, space6, space7, space8, space9, space10, space11,
                space12, space13, space14, space15, space16, space17, space18, space19, space20, space21, space22, space23,
                space24, space25, space26, space27, space28, space29, space30, space31, space32, space33, space34, space35,
                space36, space37, space38, space39};

        setUpTiles();

    }
    public void setUpTiles(){

        for(int i = 0; i < spaces.length; i++){

            boolean isCorner = false;

            if(i % 10 == 0){
                isCorner = true;
            }


            Property property = null;
            ImageView imgV = null;
            Image img = null;
            boolean isChanceOrChest = false;

            if(spaces[i].getChildren().size() == 3 /* probably or 2 in the future for utilities with no color anchor*/){

                imgV = (ImageView) spaces[i].getChildren().get(2);
                img = imgV.getImage();

                Label priceLbl = (Label) spaces[i].getChildren().get(1);
                property = new Property(priceLbl.getText());
            }else{

                imgV = (ImageView) spaces[i].getChildren().get(0);
                img = imgV.getImage();

                if(img == null){
                    img = new Image("vaderIcon.png");
                }
            }

            File file = new File(img.getUrl());
            String fName = file.getName();

            if(fName.equals("empireLogo.png") || fName.equals("rebellionLogo.png")){
                isChanceOrChest = true;
            }

            tiles[i] = new Tile(tileName[i], property, spaces[i], img, isCorner, isChanceOrChest);
        }

    }

    public void handleBoardAfterDiceRoll(int numberOfSpaces){

        int tileBeforeMove = player.getCurrentTileIndex();

        //Checking to see if new tile will be going back to start of list (going to or past go)
        int newTileIndex = (tileBeforeMove + numberOfSpaces) % tiles.length;
        player.setCurrentTile(newTileIndex);

        //Dividing by 10 to get first digit, getting the board side (since it's an int if number is less than 10
        // boardSide will equal 0)
        int boardSideBeforeMoving = tileBeforeMove / 10;
        int boardSideAfterMoving = newTileIndex / 10;

        int numberOfSidesJumpedTo = getNumSidesJumped(boardSideBeforeMoving, boardSideAfterMoving);

        rotateBoard(numberOfSidesJumpedTo);

        movePlayerPiece(newTileIndex, boardSideAfterMoving);

        setUpTilePreview(newTileIndex);
    }

    public int getNumSidesJumped(int _boardSideBeforeMoving, int _boardSideAfterMoving){

        //If Player goes from side 0 (bottom) to side 2 (top) then number of sides jumped = 2
        int numberOfSidesJumpedTo = Math.abs(_boardSideAfterMoving - _boardSideBeforeMoving);

        //If you are jumping from side 3 to side 0, the player has rounded go
        if(_boardSideBeforeMoving > _boardSideAfterMoving){

            if(numberOfSidesJumpedTo == 3){
                numberOfSidesJumpedTo = 1;

                //If numberOfSidesJumpedTo == 2, value is already correct

            }else if(numberOfSidesJumpedTo == 1){
                numberOfSidesJumpedTo = 3;
            }
        }

        return numberOfSidesJumpedTo;
    }

    public void rotateBoard(int _numberOfSidesJumpedTo){

        int addedRotation = _numberOfSidesJumpedTo * -90;

        if(_numberOfSidesJumpedTo > 0){
            RotateTransition outerRotation = new RotateTransition(Duration.millis(2000 * _numberOfSidesJumpedTo), outerBoard_ap);
            //Board will rotate by -90 degrees for each side jumped to, using cycle count so that animation will
            //play at the same speed no matter the number of jumps
            outerRotation.setByAngle(addedRotation);
            //rt.setCycleCount(numberOfSidesJumpedTo);
            outerRotation.play();

            RotateTransition innerRotation = new RotateTransition(Duration.millis(2000 * _numberOfSidesJumpedTo), innerBoard_ap);
            innerRotation.setByAngle(-addedRotation);
            innerRotation.play();

            RotateTransition playerRotation = new RotateTransition(Duration.millis(2000 * _numberOfSidesJumpedTo), playerPiece1);
            playerRotation.setByAngle(-addedRotation);
            playerRotation.play();
        }
    }

    public void movePlayerPiece(int _newTileIndex, int _boardSideAfterMoving){

        spaces[_newTileIndex].getChildren().add(player.getPlayerIcon());

        //Set player icon to default X and Y
        player.getPlayerIcon().setLayoutX(25);
        player.getPlayerIcon().setLayoutY(25);

        if(!tiles[_newTileIndex].isCornerTile()){

            //If new tile is not a corner tile, offset is necessary based on which side of the board
            //the new tile is on. By default, player location is set to corner offset
            if(_boardSideAfterMoving == 0 || _boardSideAfterMoving == 2){
                player.getPlayerIcon().setLayoutX(3);
            }else if(_boardSideAfterMoving == 1 || _boardSideAfterMoving == 3){
                player.getPlayerIcon().setLayoutY(3);
            }
        }
    }

    public void setUpTilePreview(int _newTileIndex){

        boolean isProperty = tiles[_newTileIndex].getProperty() != null;

        //region Preview Image
        Image img = tiles[_newTileIndex].getImg();
        tilePreview_img.setImage(img);
        tilePreview_img.setLayoutX(getImageOffset(img));
        //endregion

        //region Preview Color Banner & Text
        String colorStyle = ": white;";

        if(isProperty){
            colorStyle = spaces[_newTileIndex].getChildren().get(0).getStyle();

            if(colorStyle.isEmpty()){
                colorStyle = ": white;";
            }
        }

        tilePreviewColor_ap.setStyle(colorStyle);

        tilePreviewName_lbl.setText(tiles[_newTileIndex].getName());

        int delimiterIndex = colorStyle.indexOf(":");
        String isolatedColor = colorStyle.substring(delimiterIndex + 2,  colorStyle.length() - 1);

        if(isolatedColor.equals("brown") || isolatedColor.equals("blue")){
            tilePreviewName_lbl.setTextFill(Paint.valueOf("white"));
        }else{
            tilePreviewName_lbl.setTextFill(Paint.valueOf("black"));
        }


        if(isProperty){
            tilePreviewPrice_lbl.setText(tiles[_newTileIndex].getProperty().getPrice());
        }else{
            tilePreviewPrice_lbl.setText("");
        }
        //endregion

        if(tiles[_newTileIndex].isChanceOrChest){
            pulseCard();
            openCard_btn.setVisible(true);
        }

        if(tiles[_newTileIndex].isCornerTile){
            tilePreviewCard_ap.setStyle("-fx-background-color:  #c7eaca;");
        }else{
            tilePreviewCard_ap.setStyle("-fx-background-color:  white;");
        }
    }

    public int getImageOffset(Image _img){

        double aspectRatio = _img.getWidth() / _img.getHeight();
        int imageOffset = 0;

        //Very tall image -> amount of offset should decrease the wider the image
        if(aspectRatio < 0.5){
            imageOffset = 60;
        }

        //9:16 aspect ratio
        else if(aspectRatio > 0.5 && aspectRatio < 0.65){
            imageOffset = 50;
        }

        //4:5 aspect ratio
        else if(aspectRatio > 0.65 && aspectRatio < 0.9){
            imageOffset = 40;
        }

        //1:1 aspect ratio
        else if(aspectRatio > 0.9 && aspectRatio < 1.1){
            imageOffset = 20;
        }

        return imageOffset;
    }

    public void openCardAnimate(){
        pulseCardTransition.stop();

        TranslateTransition translateTransition = new TranslateTransition(Duration.seconds(1.5), tilePreviewCard_ap);
        translateTransition.setToX(100);
        translateTransition.setToY(80);
        translateTransition.play();

        translateTransition.setOnFinished(event -> {
            openCardShake();
        });
    }

    public void openCardShake(){

        audio.setFile(5);
        audio.play();

        TranslateTransition translateTransition = new TranslateTransition(Duration.seconds(0.1), tilePreviewCard_ap);
        translateTransition.setByX(20);
        translateTransition.setAutoReverse(true);
        translateTransition.setCycleCount(26);
        translateTransition.play();

        translateTransition.setOnFinished(event -> {
            openCard();
        });
    }

    public void openCard(){
        tilePreview_img.setImage(new Image("cardPopup.png"));
        openCard_btn.setVisible(false);
    }
}