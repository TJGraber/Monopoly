package com.example.tj_monopoly;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;
import java.util.Random;

public class MonopolyController {

    @FXML
    Button firstDie_btn, secondDie_btn;
    @FXML
    ImageView firstDie_img, secondDie_img;

    Image[] diceImages = {
            new Image("dOne.png"),
            new Image("dTwo.png"),
            new Image("dThree.png"),
            new Image("dFour.png"),
            new Image("dFive.png"),
            new Image("dSix.png")
    };

    public void rollDice(){

        Random random = new Random();
        int d1CurrentIndex = 5;
        int d2CurrentIndex = 5;
        int numberOfDieBounces = 15;

        for(int i = 0; i < numberOfDieBounces; i++){

//            while()
//            int randomIndexD1 = random.nextInt(6);
//            int randomIndexD2 = random.nextInt(6);

        }




        Image image = new Image("rexLogo.png");
        firstDie_img.setImage(image);

    }

}
