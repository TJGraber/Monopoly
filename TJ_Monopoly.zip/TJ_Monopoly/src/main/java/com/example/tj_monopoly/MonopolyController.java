package com.example.tj_monopoly;

public class MonopolyController {



}
