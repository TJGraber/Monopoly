package com.example.tj_monopoly;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class StartController implements Initializable {
    @FXML
    private Button newGame_btn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        newGame_btn.setOnAction(actionEvent -> {

            try {
                DBUtils.newGame(actionEvent);
            } catch (IOException | SQLException e) {
                throw new RuntimeException(e);
            }
        });
    }
}