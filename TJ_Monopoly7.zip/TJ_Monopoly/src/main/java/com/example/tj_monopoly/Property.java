package com.example.tj_monopoly;

public class Property {

    String price;


    public Property(String _price){
        price = _price;
    }

    public String getPrice(){
        return price;
    }
}
