package com.example.tj_monopoly;

import javafx.scene.layout.AnchorPane;

public class Tile {

    String name;
    Property property;
    AnchorPane anchor;
    boolean isCornerTile;

    public Tile(String _name, Property _property, AnchorPane _anchor, boolean _isCornerTile){
        name = _name;
        property = _property;
        anchor = _anchor;
        isCornerTile = _isCornerTile;
    }

    public String getName(){
        return name;
    }

    public Property getProperty(){
        return property;
    }

    public AnchorPane getAnchor(){
        return anchor;
    }
    public boolean isCornerTile(){
        return isCornerTile;
    }
}