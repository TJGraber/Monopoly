package com.example.tj_monopoly;

import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Box;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class StartController implements Initializable {
    @FXML
    Button newGame_btn, loadGame_btn, options_btn, quitGame_btn;
    @FXML
    AnchorPane crawl;
    @FXML
    ImageView background_img;

    Audio themeAudio = new Audio();
    Audio audio = new Audio();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {



        newGame_btn.setOnAction(actionEvent -> {
            try {

                audio.setFile(1);
                audio.play();

                themeAudio.stop();

                DBUtils.newGame(actionEvent);
            } catch (IOException | SQLException e) {
                throw new RuntimeException(e);
            }
        });

        newGame_btn.focusedProperty().addListener((ov, old_val, new_val) -> {
            if (new_val) {
                playMenuSound();
                background_img.setFocusTraversable(false);
            }
        });

        loadGame_btn.focusedProperty().addListener((ov, old_val, new_val) -> {
            if (new_val) {
                playMenuSound();
            }
        });

        options_btn.focusedProperty().addListener((ov, old_val, new_val) -> {
            if(new_val){
                playMenuSound();
            }
        });

        quitGame_btn.focusedProperty().addListener((ov, old_val, new_val) -> {
            if(new_val){
                playMenuSound();
            }
        });

        themeAudio.setFile(3);
        themeAudio.play();
        playStartingAnimation();
    }

    public void playStartingAnimation(){

        TranslateTransition transition = new TranslateTransition(Duration.seconds(9), crawl);
        transition.setByY(350);
        transition.play();
    }

    public void playMenuSound(){
        audio.setFile(0);
        audio.play();
    }
}