package com.example.tj_monopoly;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicInteger;

public class MonopolyController implements Initializable {

    //region FXML Compontents
    @FXML
    Button firstDie_btn, secondDie_btn;
    @FXML
    ImageView firstDie_img, secondDie_img, playerPiece1;
    @FXML
    AnchorPane space0, space1, space2, space3, space4, space5, space6, space7, space8, space9, space10, space11,
            space12, space13, space14, space15, space16, space17, space18, space19, space20, space21, space22, space23,
            space24, space25, space26, space27, space28, space29, space30, space31, space32, space33, space34, space35,
            space36, space37, space38, space39;
    @FXML
    AnchorPane outerBoard_ap, innerBoard_ap;
    //endregion

    Player player;

    Image[] diceImages = {
            new Image("dOne.png"),
            new Image("dTwo.png"),
            new Image("dThree.png"),
            new Image("dFour.png"),
            new Image("dFive.png"),
            new Image("dSixFixed.png")
    };

    AnchorPane[] spaces;
    Tile[] tiles = new Tile[40];

    int currentRotation = 0;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
    int randomIndexD1;
    int randomIndexD2;
    public void rollDice(){
        //Dice will flicker every 0.1 seconds
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(0.1), event ->{

            Random random = new Random();
            randomIndexD1 = random.nextInt(6);
            randomIndexD2 = random.nextInt(6);

            firstDie_img.setImage(diceImages[randomIndexD1]);
            secondDie_img.setImage(diceImages[randomIndexD2]);
        }));

        //15 Total "bounces"
        timeline.setCycleCount(15);
        timeline.play();

        timeline.setOnFinished(event -> {
            moveToSpace(randomIndexD1 + 1 + randomIndexD2 + 1);
            //System.out.println("hello");
        });
    }

    public void setUpPlayers(){
        player = new Player(0, playerPiece1);
    }
    public void setUpSpaces(){
        spaces = new AnchorPane[]{space0, space1, space2, space3, space4, space5, space6, space7, space8, space9, space10, space11,
                space12, space13, space14, space15, space16, space17, space18, space19, space20, space21, space22, space23,
                space24, space25, space26, space27, space28, space29, space30, space31, space32, space33, space34, space35,
                space36, space37, space38, space39};

    }
    public void setUpTiles(){

        for(int i = 0; i < spaces.length; i++){

            boolean isCorner = false;

            if(i % 10 == 0){
                isCorner = true;
            }

            tiles[i] = new Tile(spaces[i], spaces[i].getTranslateX(), spaces[i].getTranslateY() + 50, isCorner);
        }

    }

    public void moveToSpace(int numberOfSpaces){

        int currTile = player.getCurrentTileIndex();

        if(currTile + numberOfSpaces < tiles.length){


            player.setCurrentTile(currTile + numberOfSpaces);
        }else{


            int overflow = currTile + numberOfSpaces;
            player.setCurrentTile(overflow - tiles.length);
        }

        TranslateTransition translate = new TranslateTransition(Duration.seconds(0.1), outerBoard_ap);
        translate.(0);
        translate.play();

        currentRotation += 90;

        outerBoard_ap.setRotate(currentRotation);
        innerBoard_ap.setRotate(-currentRotation);

        int newTile = player.getCurrentTileIndex();
        spaces[newTile].getChildren().add(player.getPlayerIcon());
        player.getPlayerIcon().setLayoutX(3);

    }
}