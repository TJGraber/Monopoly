package com.example.tj_monopoly;

import javafx.scene.layout.AnchorPane;

public class Tile {

    AnchorPane anchor;
    double xPos;
    double yPos;
    boolean isCornerTile;

    public Tile(AnchorPane anchor, double _xPos, double _yPos, boolean _isCornerTile){
        xPos = _xPos;
        yPos = _yPos;
        isCornerTile = _isCornerTile;
    }

    public AnchorPane getAnchor(){
        return anchor;
    }

    public double getXPos(){
        return xPos;
    }
    public double getYPos(){
        return yPos;
    }
    public boolean getIsCornerTile(){
        return isCornerTile;
    }
}